package Agar::TlistItem;

use strict;
use Agar;
use Agar::Tlist;

1;

__END__

=head1 NAME

Agar::TlistItem - an item in an Agar::Tlist

=head1 SYNOPSIS

This manual page is a stub. Please see the page for Agar::Tlist instead.

=head1 SEE ALSO

L<Agar>, L<Agar::Tlist>, L<AG_Tlist(3)>

=cut
