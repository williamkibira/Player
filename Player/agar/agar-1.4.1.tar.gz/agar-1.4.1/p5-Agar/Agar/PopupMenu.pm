package Agar::PopupMenu;

use strict;
use Agar;
use Agar::Menu;

1;

__END__

=head1 NAME

Agar::PopupMenu - for right-click context menus and similar uses

=head1 SYNOPSIS

This manual page is a stub. Please see the page for Agar::Menu instead.

=head1 SEE ALSO

L<Agar>, L<Agar::Menu>, L<AG_Menu(3)>

=cut
