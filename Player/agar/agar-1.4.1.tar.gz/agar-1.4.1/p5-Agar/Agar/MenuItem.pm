package Agar::MenuItem;

use strict;
use Agar;
use Agar::Menu;

1;

__END__

=head1 NAME

Agar::MenuItem - an item within an Agar::Menu

=head1 SYNOPSIS

This manual page is a stub. Please see the page for Agar::Menu instead.

=head1 SEE ALSO

L<Agar>, L<Agar::Menu>, L<AG_Menu(3)>

=cut
