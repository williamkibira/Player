package Agar::NotebookTab;

use strict;
use Agar;
use Agar::Notebook;

1;

__END__

=head1 NAME

Agar::NotebookTab - a tab of an Agar::Notebook

=head1 SYNOPSIS

This manual page is a stub. Please see the page for Agar::Notebook.

=head1 SEE ALSO

L<Agar>, L<Agar::Notebook>, L<AG_Notebook(3)>

=cut
