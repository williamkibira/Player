/*	Public domain	*/

#ifndef _AGAR_MATH_PUBLIC_H_
#define _AGAR_MATH_PUBLIC_H_
#define _AGAR_MATH_PUBLIC
#include <agar/core.h>
#include <agar/gui.h>
#include <agar/math/m.h>
#include <agar/math/m_gui.h>
#endif /* _AGAR_MATH_PUBLIC_H_ */
