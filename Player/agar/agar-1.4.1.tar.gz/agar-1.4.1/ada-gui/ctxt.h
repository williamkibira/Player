#ifndef CTXT_H
#define CTXT_H

extern char ctxt_version[];
extern char ctxt_bindir[];
extern char ctxt_dlibdir[];
extern char ctxt_slibdir[];
extern char ctxt_incdir[];
extern char ctxt_repos[];
extern char ctxt_owner[];
extern char ctxt_group[];

#endif
