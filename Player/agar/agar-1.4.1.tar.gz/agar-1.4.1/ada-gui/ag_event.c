#include <agar/core.h>
#include <agar/gui.h>

void
agar_event_loop (void)
{
  AG_EventLoop ();
}
