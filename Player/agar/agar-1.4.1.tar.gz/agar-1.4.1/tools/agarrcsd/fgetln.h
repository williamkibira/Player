/*	Public domain	*/

char *MyFgetln(FILE *, size_t *);
