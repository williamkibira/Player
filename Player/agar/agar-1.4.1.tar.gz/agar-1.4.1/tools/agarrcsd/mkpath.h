/*	Public domain	*/

#ifndef _AGARD_MKPATH_H_
#define _AGARD_MKPATH_H_

int mkpath(char *, mode_t);

#endif /* _AGARD_MKPATH_H_ */
