/*	Public domain	*/

#undef AG_DEBUG
#undef AG_LEGACY
#undef AG_THREADS

#ifdef _AGAR_HAVE_64BIT_H_
# undef _AGAR_HAVE_64BIT_H_
# undef HAVE_64BIT
#endif
#ifdef _AGAR_HAVE_LONG_DOUBLE_H_
# undef _AGAR_HAVE_LONG_DOUBLE_H_
# undef HAVE_LONG_DOUBLE
#endif
